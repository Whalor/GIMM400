﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
/*
namespace Assets.Script.States
{
    [CreateAssetMenu(fileName = "IdleState", menuName = "Unity-States/Idle", order = 1)]
    class IdleState:AbstractState
    {
        public override bool EnterState()
        {
            base.EnterState();

            UnityEngine.Debug.Log("Entered Idle State");

            return true;
        }
        public override void UpdateState()
        {
            UnityEngine.Debug.Log("Updating Idle State");
        }


        public override bool ExitState()
        {
            base.ExitState();

            UnityEngine.Debug.Log("Exiting Idle State");

            return true;
        }
    }
}
*/