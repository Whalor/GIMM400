﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField]
    private float moveSpeed = 5;
    public float rotationSpeed;
    public GameObject tankGun;
    // Start is called before the first frame update
    void Start()
    {
        //get tankGun
        tankGun = this.gameObject.transform.GetChild(0).gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        //get horizontal movement from a and d keys
        float horizInput = Input.GetAxis("Horizontal");
        transform.Translate(new Vector3(horizInput, 0, 0) * moveSpeed * Time.deltaTime);

        //get forward movement from s and w keys
        float forwardInput = Input.GetAxis("Vertical");
        transform.Translate(new Vector3(0, 0, forwardInput) * moveSpeed * Time.deltaTime);

        //get gun rotation
        float gunRotation = Input.GetAxis("GunRot");
        tankGun.transform.Rotate(new Vector3(0, gunRotation, 0) * rotationSpeed * Time.deltaTime);
    }
}
